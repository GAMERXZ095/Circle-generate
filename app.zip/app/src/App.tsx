import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import './App.css';

// Types
type BlockStyle = 'grass' | 'stone' | 'redstone' | 'glass';
type ShapeType = 'circle' | 'ellipse';

interface GridState {
  grid: boolean[][];
  width: number;
  height: number;
}

interface ViewState {
  rotate: number;
  zoom: number;
  panX: number;
  panY: number;
}

// Block color configurations
const blockStyles: Record<BlockStyle, string> = {
  grass: 'block-grass',
  stone: 'block-stone',
  redstone: 'block-redstone',
  glass: 'block-glass',
};

// Generate circle/ellipse grid using the ellipse equation
const generatePlatform = (
  diameterX: number,
  diameterZ: number,
  shape: ShapeType
): GridState => {
  const width = Math.max(3, Math.min(diameterX, 101));
  const height = shape === 'circle' ? width : Math.max(3, Math.min(diameterZ, 101));
  
  const centerX = (width - 1) / 2;
  const centerZ = (height - 1) / 2;
  const radiusX = width / 2;
  const radiusZ = height / 2;
  
  const grid: boolean[][] = [];
  
  for (let z = 0; z < height; z++) {
    const row: boolean[] = [];
    for (let x = 0; x < width; x++) {
      // Ellipse equation: ((x - cx)^2 / rx^2) + ((z - cz)^2 / rz^2) <= 1
      const dx = x - centerX;
      const dz = z - centerZ;
      const value = (dx * dx) / (radiusX * radiusX) + (dz * dz) / (radiusZ * radiusZ);
      row.push(value <= 1);
    }
    grid.push(row);
  }
  
  return { grid, width, height };
};

// Count active blocks
const countBlocks = (grid: boolean[][]): number => {
  return grid.flat().filter(Boolean).length;
};

// Icons as SVG components
const RotateIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
    <path d="M8 2a6 6 0 1 0 6 6h-2a4 4 0 1 1-4-4V2z"/>
    <path d="M8 0l3 3-3 3V0z"/>
  </svg>
);

const ZoomInIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
    <path d="M7 1h2v5h5v2H9v5H7V8H2V6h5V1z"/>
  </svg>
);

const ZoomOutIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
    <path d="M2 6h12v2H2V6z"/>
  </svg>
);

const FitScreenIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
    <path d="M1 4V2h3V1h2v4H4V4H1zm11-3h2v2h3v2h-5V1h-2V1zm3 11v-2h3v-2h-5v4h2zm-11 0h3v2h2v-4H4v2H1z"/>
  </svg>
);

const HandIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
    <path d="M8 1a2 2 0 0 0-2 2v3H5V4a3 3 0 0 1 6 0v5.5a.5.5 0 0 0 1 0V6a2 2 0 1 1 4 0v5a5 5 0 0 1-10 0V3a2 2 0 0 0-2-2z"/>
  </svg>
);

function App() {
  // Input state
  const [diameterX, setDiameterX] = useState<number>(21);
  const [diameterZ, setDiameterZ] = useState<number>(21);
  const [shape, setShape] = useState<ShapeType>('circle');
  const [blockStyle, setBlockStyle] = useState<BlockStyle>('grass');
  
  // Grid state
  const [gridState, setGridState] = useState<GridState>({ grid: [], width: 0, height: 0 });
  const [isGenerating, setIsGenerating] = useState(false);
  const [hoveredCell, setHoveredCell] = useState<{x: number, z: number} | null>(null);
  
  // View state
  const [view, setView] = useState<ViewState>({
    rotate: 0,
    zoom: 1,
    panX: 0,
    panY: 0,
  });
  
  // Drag state
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLDivElement>(null);
  
  // Animation state
  const [animatedCells, setAnimatedCells] = useState<Set<string>>(new Set());
  
  // Tooltip state
  const [tooltip, setTooltip] = useState<{x: number, y: number, text: string} | null>(null);

  // Generate platform
  const handleGenerate = useCallback(() => {
    setIsGenerating(true);
    setAnimatedCells(new Set());
    
    const newGrid = generatePlatform(diameterX, diameterZ, shape);
    setGridState(newGrid);
    
    // Staggered animation
    const cells = new Set<string>();
    const centerX = (newGrid.width - 1) / 2;
    const centerZ = (newGrid.height - 1) / 2;
    
    // Sort cells by distance from center for center-out animation
    const activeCells: {x: number, z: number, dist: number}[] = [];
    for (let z = 0; z < newGrid.height; z++) {
      for (let x = 0; x < newGrid.width; x++) {
        if (newGrid.grid[z][x]) {
          const dist = Math.sqrt((x - centerX) ** 2 + (z - centerZ) ** 2);
          activeCells.push({ x, z, dist });
        }
      }
    }
    
    activeCells.sort((a, b) => a.dist - b.dist);
    
    // Animate cells with stagger
    activeCells.forEach((cell, index) => {
      setTimeout(() => {
        cells.add(`${cell.x},${cell.z}`);
        setAnimatedCells(new Set(cells));
      }, index * 3);
    });
    
    setTimeout(() => setIsGenerating(false), activeCells.length * 3 + 200);
  }, [diameterX, diameterZ, shape]);

  // Clear grid
  const handleClear = useCallback(() => {
    setGridState({ grid: [], width: 0, height: 0 });
    setAnimatedCells(new Set());
    setView({ rotate: 0, zoom: 1, panX: 0, panY: 0 });
  }, []);

  // Toggle individual block
  const toggleBlock = useCallback((x: number, z: number) => {
    setGridState(prev => {
      const newGrid = prev.grid.map(row => [...row]);
      if (newGrid[z] && newGrid[z][x] !== undefined) {
        newGrid[z][x] = !newGrid[z][x];
      }
      return { ...prev, grid: newGrid };
    });
  }, []);

  // Rotate view
  const handleRotate = useCallback((degrees: number) => {
    setView(prev => ({ ...prev, rotate: (prev.rotate + degrees) % 360 }));
  }, []);

  // Zoom
  const handleZoom = useCallback((delta: number) => {
    setView(prev => ({ 
      ...prev, 
      zoom: Math.max(0.3, Math.min(3, prev.zoom + delta)) 
    }));
  }, []);

  // Fit to screen
  const handleFit = useCallback(() => {
    setView({ rotate: 0, zoom: 1, panX: 0, panY: 0 });
  }, []);

  // Pan handlers
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button === 0 || e.button === 1) {
      setIsDragging(true);
      dragStart.current = { x: e.clientX - view.panX, y: e.clientY - view.panY };
      e.preventDefault();
    }
  }, [view.panX, view.panY]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isDragging) {
      setView(prev => ({
        ...prev,
        panX: e.clientX - dragStart.current.x,
        panY: e.clientY - dragStart.current.y,
      }));
    }
  }, [isDragging]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  // Touch handlers for mobile
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      dragStart.current = { 
        x: e.touches[0].clientX - view.panX, 
        y: e.touches[0].clientY - view.panY 
      };
    }
  }, [view.panX, view.panY]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (isDragging && e.touches.length === 1) {
      setView(prev => ({
        ...prev,
        panX: e.touches[0].clientX - dragStart.current.x,
        panY: e.touches[0].clientY - dragStart.current.y,
      }));
    }
  }, [isDragging]);

  const handleTouchEnd = useCallback(() => {
    setIsDragging(false);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      
      switch (e.key.toLowerCase()) {
        case 'g':
          handleGenerate();
          break;
        case 'c':
          handleClear();
          break;
        case 'r':
          handleRotate(90);
          break;
        case '+':
        case '=':
          handleZoom(0.2);
          break;
        case '-':
          handleZoom(-0.2);
          break;
        case '0':
          handleFit();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleGenerate, handleClear, handleRotate, handleZoom, handleFit]);

  // Update diameterZ when shape changes to circle
  useEffect(() => {
    if (shape === 'circle') {
      setDiameterZ(diameterX);
    }
  }, [shape, diameterX]);

  // Calculate cell size based on grid dimensions
  const cellSize = useMemo(() => {
    const maxDimension = Math.max(gridState.width, gridState.height);
    if (maxDimension <= 0) return 16;
    return Math.max(8, Math.min(20, 400 / maxDimension));
  }, [gridState.width, gridState.height]);

  // Block count
  const blockCount = useMemo(() => countBlocks(gridState.grid), [gridState.grid]);

  // Generate on initial load
  useEffect(() => {
    handleGenerate();
  }, []);

  return (
    <div className="min-h-screen stone-bg text-foreground overflow-hidden">
      {/* Header */}
      <header className="relative z-10 px-4 py-4 md:px-6 md:py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[var(--mc-green)] border-2 border-[var(--mc-green-dark)] flex items-center justify-center">
              <span className="font-pixel text-white text-xs">MC</span>
            </div>
            <h1 className="font-pixel text-sm md:text-base text-white leading-tight">
              <span className="text-[var(--mc-green)]">Minecraft</span>
              <br />
              <span className="text-xs md:text-sm text-[var(--muted-foreground)]">Circle Generator</span>
            </h1>
          </div>
          
          {/* Toolbar */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleRotate(90)}
              className="mc-button-secondary p-2"
              title="Rotate 90° (R)"
            >
              <RotateIcon />
            </button>
            <button
              onClick={() => handleZoom(0.2)}
              className="mc-button-secondary p-2"
              title="Zoom In (+)"
            >
              <ZoomInIcon />
            </button>
            <button
              onClick={() => handleZoom(-0.2)}
              className="mc-button-secondary p-2"
              title="Zoom Out (-)"
            >
              <ZoomOutIcon />
            </button>
            <button
              onClick={handleFit}
              className="mc-button-secondary p-2"
              title="Fit to Screen (0)"
            >
              <FitScreenIcon />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex flex-col lg:flex-row gap-4 px-4 pb-4 md:px-6 md:pb-6 h-[calc(100vh-80px)]">
        {/* Control Panel */}
        <aside className="lg:w-80 flex-shrink-0 animate-slide-in-left">
          <div className="mc-panel space-y-4 max-h-full overflow-y-auto">
            <h2 className="font-pixel text-xs text-[var(--mc-gold)] uppercase tracking-wider">
              Platform Settings
            </h2>
            
            {/* Shape Selection */}
            <div className="space-y-2">
              <label className="font-pixel text-[10px] text-[var(--muted-foreground)] uppercase">
                Shape
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => setShape('circle')}
                  className={`flex-1 mc-button text-[10px] ${
                    shape === 'circle' 
                      ? 'mc-button-primary' 
                      : 'mc-button-secondary'
                  }`}
                >
                  Circle
                </button>
                <button
                  onClick={() => setShape('ellipse')}
                  className={`flex-1 mc-button text-[10px] ${
                    shape === 'ellipse' 
                      ? 'mc-button-primary' 
                      : 'mc-button-secondary'
                  }`}
                >
                  Ellipse
                </button>
              </div>
            </div>

            {/* Diameter Inputs */}
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="font-pixel text-[10px] text-[var(--muted-foreground)] uppercase">
                  Diameter X (Width)
                </label>
                <input
                  type="number"
                  min="3"
                  max="101"
                  value={diameterX}
                  onChange={(e) => {
                    const val = Math.max(3, Math.min(101, parseInt(e.target.value) || 3));
                    setDiameterX(val);
                    if (shape === 'circle') {
                      setDiameterZ(val);
                    }
                  }}
                  className="mc-input"
                />
              </div>
              
              <div className="space-y-1">
                <label className={`font-pixel text-[10px] uppercase ${
                  shape === 'circle' ? 'text-[var(--muted-foreground)]/50' : 'text-[var(--muted-foreground)]'
                }`}>
                  Diameter Z (Depth)
                </label>
                <input
                  type="number"
                  min="3"
                  max="101"
                  value={diameterZ}
                  onChange={(e) => setDiameterZ(Math.max(3, Math.min(101, parseInt(e.target.value) || 3)))}
                  disabled={shape === 'circle'}
                  className="mc-input disabled:opacity-50 disabled:cursor-not-allowed"
                />
              </div>
            </div>

            {/* Block Style */}
            <div className="space-y-2">
              <label className="font-pixel text-[10px] text-[var(--muted-foreground)] uppercase">
                Block Style
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['grass', 'stone', 'redstone', 'glass'] as BlockStyle[]).map((style) => (
                  <button
                    key={style}
                    onClick={() => setBlockStyle(style)}
                    className={`mc-button text-[10px] capitalize ${
                      blockStyle === style 
                        ? 'mc-button-primary' 
                        : 'mc-button-secondary'
                    }`}
                  >
                    <span className={`inline-block w-3 h-3 mr-1 ${blockStyles[style]}`} />
                    {style}
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="w-full mc-button-primary disabled:opacity-70"
              >
                {isGenerating ? 'Generating...' : 'Generate (G)'}
              </button>
              <button
                onClick={handleClear}
                className="w-full mc-button-danger"
              >
                Clear (C)
              </button>
            </div>

            {/* Stats */}
            <div className="pt-4 border-t border-[var(--border)] space-y-2">
              <h3 className="font-pixel text-[10px] text-[var(--muted-foreground)] uppercase">
                Statistics
              </h3>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="text-[var(--muted-foreground)]">Total Blocks:</div>
                <div className="text-[var(--mc-gold)] text-right">{blockCount}</div>
                <div className="text-[var(--muted-foreground)]">Radius X:</div>
                <div className="text-white text-right">{Math.round(diameterX / 2 * 10) / 10}</div>
                <div className="text-[var(--muted-foreground)]">Radius Z:</div>
                <div className="text-white text-right">{Math.round(diameterZ / 2 * 10) / 10}</div>
              </div>
            </div>

            {/* Instructions */}
            <div className="pt-4 border-t border-[var(--border)]">
              <p className="text-[10px] text-[var(--muted-foreground)] leading-relaxed">
                <span className="text-[var(--mc-gold)]">Shortcuts:</span> G=Generate, C=Clear, R=Rotate, +/- =Zoom, 0=Fit
              </p>
            </div>
          </div>
        </aside>

        {/* Canvas Area */}
        <section 
          className="flex-1 relative mc-panel overflow-hidden cursor-grab active:cursor-grabbing"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          ref={canvasRef}
        >
          {/* Canvas Header */}
          <div className="absolute top-2 left-2 right-2 flex justify-between items-center pointer-events-none z-20">
            <div className="flex items-center gap-2 text-[10px] font-mono text-[var(--muted-foreground)]">
              <HandIcon />
              <span>Drag to pan</span>
            </div>
            <div className="text-[10px] font-mono text-[var(--muted-foreground)]">
              Zoom: {Math.round(view.zoom * 100)}% | Rotate: {view.rotate}°
            </div>
          </div>

          {/* Grid Container */}
          <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
            {gridState.width > 0 && gridState.height > 0 ? (
              <div
                className="canvas-transform"
                style={{
                  transform: `translate(${view.panX}px, ${view.panY}px) rotate(${view.rotate}deg) scale(${view.zoom})`,
                }}
              >
                {/* Axis Labels */}
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 font-pixel text-[10px] text-[var(--mc-red)]">
                  Z-
                </div>
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 font-pixel text-[10px] text-[var(--mc-red)]">
                  Z+
                </div>
                <div className="absolute -left-6 top-1/2 -translate-y-1/2 font-pixel text-[10px] text-[var(--mc-blue)]">
                  X-
                </div>
                <div className="absolute -right-6 top-1/2 -translate-y-1/2 font-pixel text-[10px] text-[var(--mc-blue)]">
                  X+
                </div>

                {/* Grid */}
                <div
                  className="grid-container border-2 border-[var(--mc-grid-line)]"
                  style={{
                    display: 'grid',
                    gridTemplateColumns: `repeat(${gridState.width}, ${cellSize}px)`,
                    gridTemplateRows: `repeat(${gridState.height}, ${cellSize}px)`,
                    gap: '1px',
                    padding: '1px',
                  }}
                >
                  {gridState.grid.map((row, z) =>
                    row.map((isActive, x) => {
                      const key = `${x},${z}`;
                      const isAnimated = animatedCells.has(key);
                      const isHovered = hoveredCell?.x === x && hoveredCell?.z === z;
                      
                      return (
                        <div
                          key={key}
                          className={`
                            block-cell
                            ${isActive ? blockStyles[blockStyle] : 'block-empty'}
                            ${isAnimated ? 'animate-pop-in' : ''}
                            ${isHovered ? 'ring-2 ring-[var(--mc-gold)]' : ''}
                          `}
                          style={{
                            width: `${cellSize}px`,
                            height: `${cellSize}px`,
                            animationDelay: `${(x + z) * 2}ms`,
                          }}
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleBlock(x, z);
                          }}
                          onMouseEnter={(e) => {
                            setHoveredCell({ x, z });
                            setTooltip({
                              x: e.clientX + 10,
                              y: e.clientY - 30,
                              text: `X: ${x - Math.floor(gridState.width / 2)}, Z: ${z - Math.floor(gridState.height / 2)}`,
                            });
                          }}
                          onMouseLeave={() => {
                            setHoveredCell(null);
                            setTooltip(null);
                          }}
                          onMouseMove={(e) => {
                            setTooltip({
                              x: e.clientX + 10,
                              y: e.clientY - 30,
                              text: `X: ${x - Math.floor(gridState.width / 2)}, Z: ${z - Math.floor(gridState.height / 2)}`,
                            });
                          }}
                        />
                      );
                    })
                  )}
                </div>

                {/* Center Marker */}
                <div 
                  className="absolute w-2 h-2 bg-[var(--mc-gold)] rounded-full pointer-events-none"
                  style={{
                    left: `calc(50% - 4px)`,
                    top: `calc(50% - 4px)`,
                  }}
                />
              </div>
            ) : (
              <div className="text-center">
                <div className="font-pixel text-sm text-[var(--muted-foreground)] mb-2">
                  No Platform Generated
                </div>
                <div className="text-xs text-[var(--muted-foreground)]/70">
                  Set dimensions and press Generate
                </div>
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="mc-tooltip fixed pointer-events-none z-50"
          style={{ left: tooltip.x, top: tooltip.y }}
        >
          {tooltip.text}
        </div>
      )}

      {/* Footer */}
      <footer className="relative z-10 px-4 py-2 text-center">
        <p className="text-[10px] text-[var(--muted-foreground)]">
          Not an official Minecraft product. Built for builders.
        </p>
      </footer>
    </div>
  );
}

export default App;
